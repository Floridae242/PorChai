(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0-r0qkq01qvd9._.css","static/chunks/node_modules_@line_liff_index_mjs_1sqa8u14g_utk._.js","static/chunks/_0f2amtzs4s55u._.js","static/chunks/node_modules_10wj5ylxwnvj8._.js"],
    source: "entry"
});
